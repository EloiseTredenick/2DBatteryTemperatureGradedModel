function  Four_C_cycled_Validation
%Code written by Ross Drummond and Eloise Tredenick, 2024, University of
%Sheffield and University of Oxford.  
%The following paper must be cited when using or modifying this code - Drummond, R., Tredenick, E.C., et al, 'Graded lithium-ion battery pouch cells to homogenise current distributions and mitigate lithium plating', 2024 (preprint).


%Fitted parameters
lambda_eff = 4.5 ;
h = 11.8;
h_tab =  51.5789;
rho = 1.2553e5;
h_faces = 210;

%Exp parameters
C_cell_Ah = 20; %Cell specific capacity in Ah
C_rate = 4;
i_app_Amps = C_cell_Ah * C_rate;

Res_value = (3.4865-3.2393801212)/(2*i_app_Amps);  %in ohms
n_cells = 42; %number of cell layers in one pouch cell
N = 24;        % Number of grid in x,y-direction -  has to be even
Nl = N-1;
N2 = Nl * Nl;

%% Cell parameters
Ly = 150e-3; %Width whole battery [m]
Lz = 200e-3; %length whole battery [m]
x_anode = 40e-6; %anode thickness in x direction [m]
x_cathode = 70e-6; %cathode thickness in x direction  [m]
Lx_onecell = x_cathode + x_anode; %x thickness 1 layer without ccs without sep - just anode and cathode

SOC0 = 0.3; %Initial SOC in experiment 
sigma_cn_al_CC = 48650000 ;
sigma_cp_copper_CC = 48650000 ;
A_cell = Ly * Lz;
Temp_init =    23.8431; %Mean initial temperature in experiment 

%% fit relaxation voltage.
theta_1 = 0.0903;
tau_1 = 0.0317;
b_1 = theta_1*tau_1/i_app_Amps;

theta_2 = 0.018;
tau_2 = 0.5;
b_2 = theta_2*tau_2/i_app_Amps;

%%
[Dcheb_y,yy] = cheb(N); Dcheb_y = (2/Ly)*Dcheb_y; DDcheb_y = Dcheb_y^2;
[Dcheb_z,zz] = cheb(N); Dcheb_z = (2/Lz)*Dcheb_z; DDcheb_z = Dcheb_z^2;

z(1:N+1,1) = Lz/2*(zz(N+1:-1:1)+1); y(1:N+1,1) = Ly/2*(yy(N+1:-1:1)+1);
[X,Y] = meshgrid(y(2:N),z(2:N));

%setup the location of the tabs
Lcn = 25e-6; %x thickness of current collector n
Lcp = 25e-6; %x thickness of current collector p
L_gap = 12.5e-3; %is distance from edges
L_tab_width = 48e-3;

for j = 1:N+1
    if y(j) <= L_gap
        start_tab1  = j;
    end
    if y(j) <= L_gap+L_tab_width
        start_tab2  = j;
    end
    if y(j) <= Ly-(L_gap+L_tab_width)
        start_tab3  = j;
    end
    if y(j) <= Ly-L_gap
        start_tab4  = j;
    end
end
start_tab5 = round(N);
tab_vec = zeros(N-1,1);
for j = 2:N
    if y(j) <= L_gap+L_tab_width && y(j) >= L_gap
        tab_vec(j-1) = 1;
    end
    if y(j) >= Ly-(L_gap+L_tab_width) && y(j) <= Ly-L_gap
        tab_vec(j-1) = 1;
    end
end
A_tab_1 = Lcp*(y(start_tab2)-y(start_tab1));
A_tab_2 = Lcn*(y(start_tab4)-y(start_tab3));
tab_mat = diag(tab_vec);
tab_mat_inv = eye(N-1)-diag(tab_vec);
I_sign_tabs = 1;
tab_bc_1 = I_sign_tabs .* i_app_Amps/(A_tab_1*sigma_cn_al_CC);
tab_bc_2 = I_sign_tabs .*i_app_Amps/(A_tab_2*sigma_cp_copper_CC);

%% Resistance matrix
gamma =  sigma_cn_al_CC*Lcn * sigma_cp_copper_CC*Lcp / (sigma_cn_al_CC*Lcn + sigma_cp_copper_CC*Lcp ) ;
Res_mat_noA = Res_value*ones(N-1,N-1);
Res_mat = Res_mat_noA*(A_cell);

%% Set up Chebfun matricies
BC_vec_y = zeros(2,N-1);
BC_vec_z = [zeros(1,start_tab1-1),tab_bc_1*ones(1,start_tab2-start_tab1),...
    zeros(1,start_tab3-start_tab2),tab_bc_2*ones(1,start_tab4-start_tab3),...
    zeros(1,start_tab5-start_tab4);zeros(1,N-1)];

DDcheb_z_in_in = DDcheb_z(2:N,2:N);
DDcheb_z_in_ex = [DDcheb_z(2:N,1),DDcheb_z(2:N,N+1)];
Dcheb_z_ex_in =  [Dcheb_z(1,2:N);Dcheb_z(N+1,2:N)];
Dcheb_z_ex_ex = [Dcheb_z(1,1),Dcheb_z(1,N+1);Dcheb_z(N+1,1),Dcheb_z(N+1,N+1)];
DDcheb_z_ex = - DDcheb_z_in_ex*(Dcheb_z_ex_ex\Dcheb_z_ex_in);
DDcheb_z_ex_bc = DDcheb_z_in_ex*(Dcheb_z_ex_ex\BC_vec_z);

DDcheb_y_in_in = DDcheb_y(2:N,2:N);
DDcheb_y_in_ex = [DDcheb_y(2:N,1),DDcheb_y(2:N,N+1)];
Dcheb_y_ex_in =  [Dcheb_y(1,2:N);Dcheb_y(N+1,2:N)];
Dcheb_y_ex_ex = [Dcheb_y(1,1),Dcheb_y(1,N+1);Dcheb_y(N+1,1),Dcheb_y(N+1,N+1)];
DDcheb_y_ex = -DDcheb_y_in_ex*(Dcheb_y_ex_ex\Dcheb_y_ex_in);
DDcheb_y_ex_bc = DDcheb_y_in_ex*(Dcheb_y_ex_ex\BC_vec_y);

eye_z = blkdiag(1,-1);
eye_y = blkdiag(1,-1);
reagain1 = blkdiag(1,0);
reagain2 = blkdiag(0,1);

Dcheb_y_ex_ex_T = eye_y*Dcheb_y_ex_ex+(h/lambda_eff)*eye(2);
Dcheb_z_ex_ex_T = eye_z*Dcheb_z_ex_ex+(h/lambda_eff)*eye(2);
DDcheb_y_ex_T_edge = -tab_mat_inv*DDcheb_y_in_ex*(Dcheb_y_ex_ex_T\(eye_y*Dcheb_y_ex_in));
DDcheb_z_ex_T = -DDcheb_z_in_ex*(Dcheb_z_ex_ex_T\(eye_z*Dcheb_z_ex_in));

Dcheb_y_ex_tab_T = eye_y*Dcheb_y_ex_ex+(h_tab/lambda_eff)*eye(2);
Dcheb_y_ex_ex_T_tab = eye_y*Dcheb_y_ex_tab_T;
DDcheb_y_ex_T_tab = -tab_mat*DDcheb_y_in_ex*((reagain1*Dcheb_y_ex_ex_T_tab+reagain2*Dcheb_y_ex_ex_T)\(eye_y*Dcheb_y_ex_in));
DDcheb_y_ex_T = DDcheb_y_ex_T_edge+ DDcheb_y_ex_T_tab ;

%% Collect parameters to save time when solving
h_faces_no_n = h_faces / n_cells;
Lx_all_n = Lx_onecell * n_cells ;
C_cell_amps = 3600 * C_cell_Ah;

%% Initial conditions
SOC_bar_s_p0 =  SOC0  .* ones(1, N2);
dUondT = -1e-4;

% OCP
V_exp_init = 3.2585;
Uocv_03  =  3.3852;
shift_term = Uocv_03-V_exp_init ;
shiftplus =   + 3.382 - shift_term ;
U_LFP_OCP_Function = @(y,T,I_sign) dUondT * T + 0.0027 * T * I_sign + shiftplus...
    + 0.0047 *(1-y) ...
    + 1.627 * exp(-81.163 *(1-y).^1.0138)...
    + 7.6445e-8 *exp(25.36 *(1-y).^2.469)...
    - 8.441e-8 *exp(25.262 *(1-y).^2.478);
Ucathode0 =  U_LFP_OCP_Function(SOC0,0,1);

%% Initial conditions
T_0bar = zeros(1, N2);
V_0 = Ucathode0.* ones(1, N2) + Res_value .*i_app_Amps ;
Vrel_0 = zeros(1,N2);
ICs_0_orig = [SOC_bar_s_p0 T_0bar V_0 Vrel_0 Vrel_0];

%% M - mass matrix
D_pat_xrd = eye(N2, N2);
Z_pat_x = zeros(N2, N2);
M= [D_pat_xrd  Z_pat_x   Z_pat_x
    Z_pat_x    D_pat_xrd Z_pat_x
    Z_pat_x    Z_pat_x   Z_pat_x      ];

M = blkdiag(M,eye(N2),eye(N2));

T_store_100 = zeros((N-1)^2,1);
T_store_500 = zeros((N-1)^2,1);
T_store_1000 = zeros((N-1)^2,1);
T_store_2500 = zeros((N-1)^2,1);

%% Setup to solve
n_loop = 50; %switches every 50sec
opts = odeset('Mass',M);
T_dim_11 =[];
V_dim_1  =  [];
time_set_loop = [];
for gg = 1:n_loop
    I_sign = (-1)^gg; %Changes sign for discharge/charge

    %% Solve using ODE15s
    [time_set,phi_sol] = ode15s(@(t,z)rhs(t,z,I_sign),[0 n_loop],ICs_0_orig(:), opts);
    ICs_0_orig(:) = phi_sol(end,:)';

    %Extract the solution
    SOC_loop = phi_sol(:, 1 : N2);
    T_loop = phi_sol(:, N2 + 1 : 2*N2);
    V_loop  =  phi_sol(:,2*N2 + 1 : 3 *N2 );
    Vrelax_loop =  phi_sol(:,3*N2 + 1 : 4 *N2 );
    Vrelax2_loop =  phi_sol(:,4*N2 + 1 : 5 *N2 );
    U_1 = U_LFP_OCP_Function(SOC_loop,T_loop,I_sign);
    out_of_equilib_volt = V_loop-U_1-Vrelax_loop-Vrelax2_loop;
    T_dim_11 = [T_dim_11;T_loop ];
    V_dim_1  =  [V_dim_1;V_loop];
    time_set_loop = [time_set_loop;time_set+(gg-1)*n_loop];
    if  gg ==2
        T_store_100 = T_loop;
    elseif gg == 10
        T_store_500 = T_loop;
    elseif gg == 20
        T_store_1000 = T_loop;
    elseif gg == 50
        T_store_2500 = T_loop;
    end
end

%% Values for plotting
Tn_1 = size(V_dim_1,1);
T_dim_1 = reshape(T_dim_11,Tn_1,N-1,N-1) + Temp_init;
nt = size(T_dim_1,1);
max_T = zeros(nt,1);
min_T = zeros(nt,1);
mean_T = zeros(nt,1);
for j = 1:nt
    max_T(j) = max(T_dim_1(j,:));
    min_T(j) = min(T_dim_1(j,:));
    mean_T(j) = mean(T_dim_1(j,:));
end
mean_V = zeros(nt,1);
for j = 1:nt
    mean_V(j) = mean(V_dim_1(j,:));
end

%% Plot
level_1 = [24.3,24.4,24.5,24.6,24.7,24.8,24.9,25];
level_2 = [28, 28.1, 28.2,28.3,28.4,28.6,29,29.2,29.4,29.6,29.8,30];
l_width = 2;
color_mod = [1 1 1];
f_size = 15;

%% Plot model solution - T
figure;
hold on
T_plot_fit1 = reshape(T_store_100(end,:)+Temp_init,N-1,N-1);
contourf(X,Y,flip(T_plot_fit1),level_1,'showtext','on',FaceAlpha=0.5)
contourf(X,Y,flip(T_plot_fit1),'showtext','on',FaceAlpha=0.5)
g = gca;
set(g, 'fontsize',f_size-2);
grid on
xlabel('y [m]','interpreter','latex','fontsize',f_size+5);
ylabel('z [m]','interpreter','latex','fontsize',f_size+5); hold off;
zlabel('T','interpreter','latex','fontsize',f_size);
box;
axis([0 Ly 0 Lz])
colormap(gray);

hold on
figure;
T_plot_fit2 = reshape(T_store_500(end,:)+Temp_init,N-1,N-1);
contourf(X,Y,flip(T_plot_fit2),level_2,'showtext','on',FaceAlpha=0.5)
g = gca;
set(g, 'fontsize',f_size-2);
grid on
xlabel('y [m]','interpreter','latex','fontsize',f_size+5);
ylabel('z [m]','interpreter','latex','fontsize',f_size+5); hold off;
zlabel('T','interpreter','latex','fontsize',f_size);
axis([0 Ly 0 Lz])
colormap(gray);

figure;
hold on
T_plot_fit3 = reshape(T_store_1000(end,:)+Temp_init,N-1,N-1);
contourf(X,Y,flip(T_plot_fit3),'showtext','on',FaceAlpha=0.5)
g = gca;
set(g, 'fontsize',f_size-2);
grid on
xlabel('y [m]','interpreter','latex','fontsize',f_size+5);
ylabel('z [m]','interpreter','latex','fontsize',f_size+5); hold off;
zlabel('T','interpreter','latex','fontsize',f_size);
box;
axis([0 Ly 0 Lz])
colormap(gray);

figure;
hold on
T_plot_fit4 = reshape(T_store_2500(end,:)+Temp_init,N-1,N-1);
contourf(X,Y,flip(T_plot_fit4),'showtext','on',FaceAlpha=0.5)
g = gca;
set(g, 'fontsize',f_size-2);
grid on
xlabel('y [m]','interpreter','latex','fontsize',f_size+5);
ylabel('z [m]','interpreter','latex','fontsize',f_size+5); hold off;
zlabel('T','interpreter','latex','fontsize',f_size);
box;
axis([0 Ly 0 Lz])
colormap(gray);

figure;
plot(time_set_loop,min_T','--k','color',0.1*color_mod,'linewidth',l_width);hold all;
plot(time_set_loop,mean_T','--k','color',0.5*color_mod,'linewidth',l_width);
plot(time_set_loop,max_T','--k','color',0.7*color_mod,'linewidth',l_width);
grid on
g = gca;
set(g, 'fontsize',f_size-2);
xlabel('Time [s]','interpreter','latex','fontsize',f_size);
ylabel('Temperature [deg]','interpreter','latex','fontsize',f_size); hold off;
leg = legend('Min (model)','Mean (model)','Max (model)');
set(leg,'fontsize',15,'location','southeast','interpreter','latex')

figure;
plot(time_set_loop,mean_V','color',0.5*color_mod,'linewidth',l_width);
grid on
g = gca;
set(g, 'fontsize',f_size-2);
xlabel('Time [s]','interpreter','latex','fontsize',f_size);
ylabel('Voltage [V]','interpreter','latex','fontsize',f_size); hold off;
leg = legend('Model');
set(leg,'fontsize',16,'location','southeast','interpreter','latex')

    function out = rhs(~,X,I_sign)
        % Change vectors into matrix for 2D simulation
        SOC = reshape(X(1 : N2,1),Nl,Nl);
        T = reshape(X(N2 + 1 : 2*N2 ,1),Nl,Nl);
        Volt = reshape(X(2*N2 + 1 : 3 *N2 ,1),Nl,Nl);
        Vrelax_1 = reshape(X(3*N2 + 1 : 4 *N2 ,1),Nl,Nl);
        Vrelax_2 = reshape(X(4*N2 + 1 : 5 *N2 ,1),Nl,Nl);

        out_of_equilib_volt = Volt - U_LFP_OCP_Function(SOC,T,I_sign) - Vrelax_1 - Vrelax_2;
        I_eval = A_cell*out_of_equilib_volt./  Res_mat;
        SOC_dt = I_eval./ C_cell_amps; 

        %% T
        FT_z = lambda_eff.*((DDcheb_z_in_in + DDcheb_z_ex_T)*T);
        FT_y= lambda_eff.*((DDcheb_y_in_in + DDcheb_y_ex_T)*T');
        IsqR_term = (out_of_equilib_volt).^2./(Lx_all_n* Res_mat_noA);
        T_dt = ( FT_z+ FT_y' + IsqR_term - h_faces_no_n .* T ) ./rho; 

        %% V
        FV_z = ((DDcheb_z_in_in + DDcheb_z_ex)*Volt- I_sign*DDcheb_z_ex_bc);
        FV_y = ((DDcheb_y_in_in + DDcheb_y_ex)*Volt'- I_sign*DDcheb_y_ex_bc);
        FV = FV_z + FV_y' - out_of_equilib_volt./ ( gamma .* Res_mat );

        %% Relaxation voltage
        dVreldt_1 = -tau_1 * Vrelax_1 + b_1 * I_eval;
        dVreldt_2 = -tau_2 * Vrelax_2 + b_2 * I_eval;
        %%
        out = [reshape(SOC_dt,N2,1);reshape(T_dt,N2,1);reshape(FV,N2,1);reshape(dVreldt_1,N2,1);reshape(dVreldt_2,N2,1)];
        out = out(:);
    end
end