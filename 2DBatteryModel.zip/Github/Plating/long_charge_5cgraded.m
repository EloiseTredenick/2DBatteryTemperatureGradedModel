function long_charge_5cgraded

%% Plating for uniform cell just at 5C
% Code written by Ross Drummond and Eloise Tredenick, University of
% Sheffield and University of Oxford. 

C_rate = 5;

%Fitting
lambda_eff = 4.5 ;
h = 11.5 ;
h_tab =  51.5789;
rho = 1.2553e5;

one_C_Ah = 20;
C_cell_nom = one_C_Ah;

i_app_Amps = one_C_Ah*C_rate;

h_faces = 210;
Res_value = (3.4865-3.2393801212)/(2*i_app_Amps);  
n_cells = 42; 
N = 24;

%% Cell parameters
Ly = 150e-3; %Width whole battery
Lz = 200e-3; %length whole battery
Lx_onecell = (40+70)*1e-6;%x thickness 1 layer without ccs without sep - just anode and cathode

SOC0 = 0.3;
v_max = 3.9;
v_max = 3.85;
sigma_cn_al_CC = 48650000 ;
sigma_cp_copper_CC = 48650000 ;
A_cell = Ly * Lz;

%% fit relaxation voltage.
theta_1 = 0.0903;
tau_1 = 0.0317;
b_1 = theta_1*tau_1/i_app_Amps;
theta_2 = 0.018;
tau_2 = 0.5;
b_2 = theta_2*tau_2/i_app_Amps;

%%
Nl = N-1;
N2 = Nl * Nl;

[Dcheb_y,yy] = cheb(N); Dcheb_y = (2/Ly)*Dcheb_y; DDcheb_y = Dcheb_y^2;
[Dcheb_z,~] = cheb(N); Dcheb_z = (2/Lz)*Dcheb_z; DDcheb_z = Dcheb_z^2;

y(1:N+1,1) = Ly/2*(yy(N+1:-1:1)+1);

Lcn = 25e-6; %x thickness of current collector n
Lcp = 25e-6; %x thickness of current collector p
L_gap = 12.5e-3; %is distance from edges
L_tab_width = 48e-3;

for j = 1:N+1
    if y(j) <= L_gap
        start_tab1  = j;
    end
    if y(j) <= L_gap+L_tab_width
        start_tab2  = j;
    end
    if y(j) <= Ly-(L_gap+L_tab_width)
        start_tab3  = j;
    end
    if y(j) <= Ly-L_gap
        start_tab4  = j;
    end
end
start_tab5 = round(N);
tab_vec = zeros(N-1,1);
for j = 2:N
    if y(j) <= L_gap+L_tab_width && y(j) >= L_gap
        tab_vec(j-1) = 1;
    end
    if y(j) >= Ly-(L_gap+L_tab_width) && y(j) <= Ly-L_gap
        tab_vec(j-1) = 1;
    end
end
n_reshape_tab = 162;

A_tab_1 = Lcp*(y(start_tab2)-y(start_tab1));
A_tab_2 = Lcn*(y(start_tab4)-y(start_tab3));

tab_mat = diag(tab_vec);
tab_mat_inv = eye(N-1)-diag(tab_vec);

tab_bc_1 = i_app_Amps/(A_tab_1*sigma_cn_al_CC);
tab_bc_2 = i_app_Amps/(A_tab_2*sigma_cp_copper_CC);

%% Resistance matrix- plotted directly.
gamma =  sigma_cn_al_CC*Lcn * sigma_cp_copper_CC*Lcp / (sigma_cn_al_CC*Lcn + sigma_cp_copper_CC*Lcp ) ;%goes in front of omega and I
Res_mat_load = load('var_save.mat');
Res_mat = Res_mat_load.Res_mat;
Res_mat_noA = Res_mat/A_cell;

%%
BC_vec_y = zeros(2,N-1);
BC_vec_z = [zeros(1,start_tab1-1),tab_bc_1*ones(1,start_tab2-start_tab1),...
    zeros(1,start_tab3-start_tab2),tab_bc_2*ones(1,start_tab4-start_tab3),...
    zeros(1,start_tab5-start_tab4);zeros(1,N-1)];

DDcheb_z_in_in = DDcheb_z(2:N,2:N);
DDcheb_z_in_ex = [DDcheb_z(2:N,1),DDcheb_z(2:N,N+1)];
Dcheb_z_ex_in =  [Dcheb_z(1,2:N);Dcheb_z(N+1,2:N)];
Dcheb_z_ex_ex = [Dcheb_z(1,1),Dcheb_z(1,N+1);Dcheb_z(N+1,1),Dcheb_z(N+1,N+1)];
DDcheb_z_ex = -DDcheb_z_in_ex*(Dcheb_z_ex_ex\Dcheb_z_ex_in);
DDcheb_z_ex_bc = DDcheb_z_in_ex*(Dcheb_z_ex_ex\BC_vec_z);

DDcheb_y_in_in = DDcheb_y(2:N,2:N); 
DDcheb_y_in_ex = [DDcheb_y(2:N,1),DDcheb_y(2:N,N+1)];
Dcheb_y_ex_in =  [Dcheb_y(1,2:N);Dcheb_y(N+1,2:N)];  Dcheb_y_ex_ex = [Dcheb_y(1,1),Dcheb_y(1,N+1);Dcheb_y(N+1,1),Dcheb_y(N+1,N+1)];
DDcheb_y_ex = -DDcheb_y_in_ex*(Dcheb_y_ex_ex\Dcheb_y_ex_in);
DDcheb_y_ex_bc = DDcheb_y_in_ex*(Dcheb_y_ex_ex\BC_vec_y);

eye_z = blkdiag(1,-1);
eye_y = blkdiag(1,-1);
reagain1 = blkdiag(1,0);
reagain2 = blkdiag(0,1);

Dcheb_y_ex_ex_T = eye_y*Dcheb_y_ex_ex+(h/lambda_eff)*eye(2);
Dcheb_z_ex_ex_T = eye_z*Dcheb_z_ex_ex+(h/lambda_eff)*eye(2);
DDcheb_y_ex_T_edge_bc = -tab_mat_inv*DDcheb_y_in_ex*(Dcheb_y_ex_ex_T\(eye_y*Dcheb_y_ex_in));
DDcheb_z_ex_T = -DDcheb_z_in_ex*(Dcheb_z_ex_ex_T\(eye_z*Dcheb_z_ex_in));

Dcheb_y_ex_tab_T = eye_y*Dcheb_y_ex_ex+(h_tab/lambda_eff)*eye(2);
Dcheb_y_ex_ex_T_tab = eye_y*Dcheb_y_ex_tab_T;
DDcheb_y_ex_T_tab_bc = -tab_mat*DDcheb_y_in_ex*((reagain1*Dcheb_y_ex_ex_T_tab+reagain2*Dcheb_y_ex_ex_T)\(eye_y*Dcheb_y_ex_in));

DDcheb_y_ex_T_bc = DDcheb_y_ex_T_edge_bc+ DDcheb_y_ex_T_tab_bc ;

%% Dimensionless initial conditions
SOC_bar_s_p0 =  SOC0  .* ones(1, N2);
dUondT = -1e-4;

%% Functions - OCP
V_exp_init = 3.2585;
Uocv_03  =  3.3852;
shift_term = Uocv_03-V_exp_init ;
U_Discharge = @(y,T) dUondT .* T ...
    + 3.382+0.0047.*(1-y)+1.627.*exp(-81.163.*(1-y).^1.0138)+7.6445e-8.*exp(25.36.*(1-y).^2.469) - 8.441e-8.*exp(25.262.*(1-y).^2.478)-shift_term;
Ucathode0 =  U_Discharge(SOC0,0);

%% Initial conditions
T_0bar = zeros(1, N2);
V_0 = Ucathode0.* ones(1, N2) + Res_value .*i_app_Amps ;
Vrel_0 = zeros(1,N2);
ICs_0_orig = [SOC_bar_s_p0 T_0bar V_0 Vrel_0 Vrel_0];

%% M - mass matrix
D_pat_xrd = eye(N2, N2);
Z_pat_x = zeros(N2, N2);
M= [ D_pat_xrd  Z_pat_x   Z_pat_x
    Z_pat_x    D_pat_xrd  Z_pat_x
    Z_pat_x    Z_pat_x   Z_pat_x      ];
M = blkdiag(M,eye(N2),eye(N2));

%% Setup to solve with ODE15s
reltol = 1e-7;
abstol = 1e-8;
opts = odeset('RelTol',reltol,'AbsTol', abstol ,'Mass',M,'Events', @(t,phi_sol) DFN_event(t,phi_sol));
Res_mat_vector = reshape(Res_mat,Nl^2,1);

tf = (1-SOC0)*3600/C_rate;
time_set = linspace(0,tf,tf);
[time_solve,phi_sol] = ode15s(@rhs, time_set,ICs_0_orig(:), opts);

SOC_loop = phi_sol(:, 1 : N2);
T_loop = phi_sol(:, N2 + 1 : 2*N2);
V_loop  =  phi_sol(:,2*N2 + 1 : 3 *N2 );
Vrelax_loop =  phi_sol(:,3*N2 + 1 : 4 *N2 );
Vrelax2_loop =  phi_sol(:,4*N2 + 1 : 5 *N2 );
U_1 = U_Discharge(SOC_loop,T_loop);

out_of_equilib_volt = V_loop-U_1-Vrelax_loop-Vrelax2_loop;
I_loop = A_cell*(out_of_equilib_volt)./ Res_mat_vector';

%% Plating
Nl = N-1;
nt = max(size(time_solve));

a_lp = 1.74; 
b_lp = 9.32; 
c_lp = 4.46;
d_lp = (0.6653/80)*(4/6);

gc = zeros(Nl,Nl,nt); 
plating_check = zeros(nt,1); 
gc_sign  = zeros(Nl,Nl);

area_norm = compute_integral(ones(Nl,Nl),Nl-2,N-2);
for kk= 1:nt
    SOC_plating = reshape(SOC_loop(kk,:),Nl,Nl);
    I_plating  = reshape(I_loop(kk,:),Nl,Nl);
    gc(:,:,kk) = a_lp*log(b_lp*SOC_plating) -c_lp+I_plating*d_lp;
    gc_sign = gc_sign + (sign(gc(:,:,kk))+ones(Nl,Nl))/2;
    for ll = 1:Nl
        for l = 1:Nl
            if gc_sign(ll,l) >=1
                gc_sign(ll,l)= 1;
            end
        end
    end
    plating_check_init(kk) = compute_integral(gc_sign,Nl-2,N-2);
    plating_check(kk) = 100*plating_check_init(kk)/area_norm;
end

%% - Plots
l_width = 2;
f_size = 12;

figure;
plot(time_solve,plating_check,'color',0.1*[1 1 1],'linewidth',l_width);
grid on
xlabel('Time [s]','interpreter','latex','fontsize',f_size);
ylabel('Percentage of particles plating [\%]','interpreter','latex','fontsize',f_size); 

%%
figure;
plot(time_solve,V_loop(:,n_reshape_tab),'color',0.1*[1 1 1],'linewidth',l_width);
grid on
xlabel('Time [s]','interpreter','latex','fontsize',f_size);
ylabel('Voltage at tab [V]','interpreter','latex','fontsize',f_size); 

figure;
plot(time_solve,SOC_loop(:,n_reshape_tab),'color',0.1*[1 1 1],'linewidth',l_width);
grid on
xlabel('Time [s]','interpreter','latex','fontsize',f_size);
ylabel('SoC at tab [-]','interpreter','latex','fontsize',f_size); 

figure;
plot(time_solve,I_loop(:,n_reshape_tab),'color',0.1*[1 1 1],'linewidth',l_width);
grid on
xlabel('Time [s]','interpreter','latex','fontsize',f_size);
ylabel('Current at tab [A]','interpreter','latex','fontsize',f_size);

    function out = rhs(~,X)
        % Turn vectors into 2D matrix
        SOC = reshape(X(1 : N2,1),Nl,Nl);
        for jj = 1:Nl
            for gg = 1:Nl
                if SOC(jj,gg)<=0
                    SOC(jj,gg)=0;
                elseif SOC(jj,gg)>=1
                    SOC(jj,gg)= 1;
                end
            end
        end
        T = reshape(X(N2 + 1 : 2*N2 ,1),Nl,Nl);
        V_1 = reshape(X(2*N2 + 1 : 3 *N2 ,1),Nl,Nl);
        Vrelax = reshape(X(3*N2 + 1 : 4 *N2 ,1),Nl,Nl);
        Vrelax_2 = reshape(X(4*N2 + 1 : 5 *N2 ,1),Nl,Nl);
        Ucathodebar =   U_Discharge(SOC,T);

        out_of_equilib_volt = V_1 - Ucathodebar-Vrelax-Vrelax_2;

        I_eval = A_cell*out_of_equilib_volt./ Res_mat;
        SOC_dt = I_eval./(3600*C_cell_nom);

        %% T
        FT_z = lambda_eff.*((DDcheb_z_in_in + DDcheb_z_ex_T)*T);
        FT_y= lambda_eff.*((DDcheb_y_in_in + DDcheb_y_ex_T_bc)*T');
        IsqR_term = out_of_equilib_volt.^2./(Lx_onecell*Res_mat_noA*n_cells);
        T_dt = 1*( FT_z+ FT_y' + IsqR_term - h_faces .* T ./ n_cells ) ./rho;

        %% V
        FV_z = ((DDcheb_z_in_in + DDcheb_z_ex)*V_1 + DDcheb_z_ex_bc);
        FV_y = ((DDcheb_y_in_in + DDcheb_y_ex)*V_1' + DDcheb_y_ex_bc);
        FV = FV_z + FV_y' - out_of_equilib_volt./ ( gamma .* Res_mat );

        %% Relaxation voltage
        dVreldt = -tau_1*Vrelax+b_1.*I_eval;
        dVreldt_2 = -tau_2*Vrelax_2+b_2.*I_eval;
        %%
        out = [reshape(SOC_dt,Nl^2,1);reshape(T_dt,Nl^2,1);reshape(FV,Nl^2,1);reshape(dVreldt,Nl^2,1);reshape(dVreldt_2,Nl^2,1)];
        out = out(:);
    end
    function [value,isterminal,direction] = DFN_event(~,phi_sol)
        %V - cut off when reach v_min
        V_tab = phi_sol(2*N2 + 1 +n_reshape_tab );
        value(1)        =  v_max-V_tab;
        isterminal(1)    =  1;
        direction(1)    =  0;  %for discharging
    end
    function I = clenshaw_curtis(f,n) % (n+1)-pt C-C quadrature of f
        fx = f/(2*n); % f evaluated at these points
        g = real(fft(fx([1:n+1 n:-1:2]))); % Fast Fourier Transform
        a = [g(1); g(2:n)'+g(2*n:-1:n+2)'; g(n+1)]; % Chebyshev coefficients
        w = 0*a'; 
        w(1:2:end) = 2./(1-(0:2:n).^2); % weight vector
        I = w*a; % the integral
    end
    function int_all = compute_integral(practice,Nl,N)
        for gg = 1:Nl+2
            int_set(gg) =  clenshaw_curtis(practice(gg,:),N);
        end
        int_set_x =  clenshaw_curtis(int_set,N); int_all =  int_set_x/4;
    end
end